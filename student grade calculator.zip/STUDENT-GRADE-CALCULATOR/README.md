# STUDENT-GRADE-CALCULATOR
Input: Take marks obtained (out of 100) in each subject. Calculate Total Marks: Sum up the marks obtained in all subjects. Calculate Average Percentage: Grade Calculation: Assign grades based on the average percentage achieved. Display Results: Show the total marks, average percentage, and the corresponding grade to the use
